# -*- coding: utf-8 -*-

from . import ks_stock_location_extension
from . import ks_res_users_extension
